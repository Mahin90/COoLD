# Luxury
pro cloner
<b></b> </br> <br>[![Github](https://img.shields.io/badge/Github-Niki404-Cyber-dimgray?style=flat-square&logo=github)](https://github.com/Niki404-Cyber)<br> [![Facebook](https://img.shields.io/badge/Facebook-Mr.NIKI-blue?style=flat-square&logo=facebook)](https://www.facebook.com/NIKI.CYBER404.OFFICIALS)<br> [![WhatsApp](https://img.shields.io/badge/WhatsApp-Mr.NIKI-blue?style=flat-square&logo=WhatsApp)](https://chat.whatsapp.com/IulgtTY1ao6HeowtyCFEGJ)

<h1 align="center"> ERROR PROBLEM FIXED </h1>

<h2 align="center"> ADMIN : Mr.NIKI</h2>

<h3 align="center"> LOGIN WITH USERNAME & PASSWORD</h3>

<h4 align="center"> INDIAN FACEBOOK ID CLONE</h4>

<h5 align="center"> NEW INDIA-CRACK TOOLS</h5>


## <b>Installation</b>

```
$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ pip install requests
$ pip install mechanize
$ pip install bs4
$ pip install rich
$ pkg install git
$ rm -rf Luxury
$ git clone https://github.com/Niki404-Cyber/Luxury
$ cd Luxury
$ python Luxury.py

Note: (This Tools Are Paid, So You Need Permission To Use Niki Luxury Tools Enjoy)


```

# Single Command 

```
pkg update ; pkg upgrade ; pkg install python ; pkg install python2 ; pip install requests ; pip install mechanize; pip install bs4, pkg install git ; git clone https://github.com/Niki404-Cyber/Luxury.git ; cd Luxury; python Luxury.py

Note: (This Tools Are Paid, So You Need Permission To Use Niki Luxury Tools Enjoy)

```

[![Facebook](https://img.shields.io/badge/Facebook-Mr.NIKI-blue?style=flat-square&logo=facebook)](https://www.facebook.com/Tera.Bap.Ka.Link.Hain)</br>
[CODED BY Mr. NIKI]

