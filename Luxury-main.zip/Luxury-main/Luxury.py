import os, sys
try:
    __import__("vivomo").__niki____()
except Exception as e:
    exit(str(e))
